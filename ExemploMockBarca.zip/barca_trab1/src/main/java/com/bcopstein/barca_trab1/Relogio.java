package com.bcopstein.barca_trab1;

public interface Relogio{
    int getHora();
    int getMinuto();
}